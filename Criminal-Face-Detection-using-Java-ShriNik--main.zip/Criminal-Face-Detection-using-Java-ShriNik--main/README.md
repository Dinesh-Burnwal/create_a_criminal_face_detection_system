# Criminal-Face-Detection-using-Java-ShriNik-
The goal of the Criminal Face Detection System project is to develop a Criminal Face Detection system using human memory for specific facial characteristics. There are several ways to identify culprits at the crime site, including fingerprinting, and eyewitness testimony. 
